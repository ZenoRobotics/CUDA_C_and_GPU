## Simple Kernel Launch

*This program tests the functionality of cuda by running an empty kernel with 1 block and 1 thread and then printing "Hello World".*

---
<br>